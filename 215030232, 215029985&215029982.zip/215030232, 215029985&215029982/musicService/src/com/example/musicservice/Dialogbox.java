package com.example.musicservice;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;

public class Dialogbox extends DialogFragment {
	LayoutInflater inflater;
	View v;
	
	@Override
	@NonNull
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		
		inflater= getActivity().getLayoutInflater();
		v=inflater.inflate(R.layout.activity_music23, null);
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		builder.setView(v).setPositiveButton("OK", new OnClickListener() {
			
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				
			}
		}).setNegativeButton("Cancer", new OnClickListener() {
			
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				
			}
		});
		
		return  builder.create();
		
	}

}

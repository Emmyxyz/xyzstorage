package com.example.musicservice;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;


public class Music3 extends Activity {
	public MediaPlayer myplay;
	//public File raw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music2);
        Button btnnex = (Button )findViewById(R.id.bc);
        Button btn = (Button )findViewById(R.id.btntoast);
        Button sub = (Button )findViewById(R.id.btnsub);
        sub.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent= new Intent(getApplicationContext(),Dialogbox.class);
				startActivity(intent);
				
			}
		});
        btnnex.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				finish();
				System.exit(0);
				
			}
		});
        btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Toast.makeText(Music3.this, "Congraturation you have done it!", Toast.LENGTH_LONG).show();
			}
		});
        
        
        }
    public void loginMethod(View v)
    {
    	Dialogbox dialo = new Dialogbox();
    	FragmentManager getSupportFragmentManager = null;
		dialo.show(getSupportFragmentManager, "my dialog");
    }
   

}

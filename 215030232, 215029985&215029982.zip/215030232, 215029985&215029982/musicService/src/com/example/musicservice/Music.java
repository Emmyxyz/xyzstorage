package com.example.musicservice;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;


public class Music extends Activity {
	public MediaPlayer myplay;
	//public File raw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music);
        
        Button btnstart = (Button )findViewById(R.id.btnstart);
        Button btnstop = (Button )findViewById(R.id.btnstop);
        Button btnexi = (Button )findViewById(R.id.exitb);
        Button btnnex = (Button )findViewById(R.id.next);
        
        btnstart.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				onCreate();
				Toast.makeText(Music.this, "Iratangiye muryoherwe!", Toast.LENGTH_LONG).show();
				
			}
			
		});
        btnstop.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				onDestroy();
				//Toast.makeText(Music.this, "Service stoped", Toast.LENGTH_LONG).show();
				
			}
		});
        btnexi.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
				System.exit(0);
				
			}
		});
        
        btnnex.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				Intent xyz=new Intent(getApplicationContext(), Music3.class);
				startActivity(xyz);
				
			}
		});
        
    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
    		ContextMenuInfo menuInfo) {
    	// TODO Auto-generated method stub
    	getMenuInflater().inflate(R.menu.music, menu);
    	
    	super.onCreateContextMenu(menu, v, menuInfo);
    }
    


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.music, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
       switch (item.getItemId()) {
	case R.id.exitt:
		finish();
		System.exit(0);

		
		
		
		
	}
        return super.onOptionsItemSelected(item);
        
    }
    public void onCreate(){
    	Toast.makeText(this, "service started", Toast.LENGTH_SHORT).show();
    	myplay=MediaPlayer.create(this, R.raw.dion);
    	myplay.setLooping(true);
    	myplay.start();

    }
    public void onDestroy(){
    	Toast.makeText(this, "Service Stoped", Toast.LENGTH_LONG).show();
    	myplay.pause();
    	
        }
   

}
